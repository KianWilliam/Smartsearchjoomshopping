SearchJshopping - Version 1.0.0  is a free software which is developed by
KWProductions Co.
The plugin is designed for smartsearch component and module of Joomla 4!
The license is GNU/GPLv3
For those who are using Component Joomshopping for joomla 4,
download from : www.joomshopping.com, then employ this plugin along with it shall
enable you to  use smartsearch module of J4 and  smartsearch component of joomla 4 to index product items
to find related products. 
you may download the plugin at:
https://www.extensions.kwproductions121.com/myplugins/smartsearcjshopping.html
also in case of any question email me at:
webarchitect@kwproductions121.com
or go to http://www.extensions.kwproductions121.com/support.html and send us a message.
long live science.
